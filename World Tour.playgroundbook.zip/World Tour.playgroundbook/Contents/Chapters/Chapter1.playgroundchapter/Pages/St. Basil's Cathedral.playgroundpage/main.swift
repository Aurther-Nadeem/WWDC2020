/*:
# St. Basil's Cathedral, Moscow, Russia
The Cathedral with the colourful domes

Welcome to Moscow. Moscow is actually named after a river and is regularly named one of the most expensive cities in the world.

Here's some fun facts about Moscow:
- Tram number 3 is the oldest running route in Moscow dating back to 6/4/1899.
- Only 2% of Moscow's population have family history in Moscow.
- Moscow is the largest city in Europe.
- Dogs in Moscow aren't allowed to bark from 11pm to 7am.
- 9,000,000 people use the Moscow metro daily.

Make sure to get up and walk around St. Basil's Cathedral.

- Important:
For the best User Experience turn off silent mode, turn up your volume 🔊, turn on Dark Mode 🌙 and hold your iPad Pro horizontally.

Go to the [next page](@next) when you're ready to move on.
*/

import PlaygroundSupport
import RealityKit
import UIKit
import ARKit
import AVFoundation

var player: AVAudioPlayer?

let path = Bundle.main.path(forResource: "Moscow.m4a", ofType: nil)!
let url = URL(fileURLWithPath: path)

let arView = ARView(frame:.infinite, cameraMode: .ar, automaticallyConfigureSession: true)

let config = ARWorldTrackingConfiguration()
config.planeDetection = .horizontal
config.isLightEstimationEnabled = true

let coachingOverlay = ARCoachingOverlayView()
coachingOverlay.session = arView.session
coachingOverlay.translatesAutoresizingMaskIntoConstraints = false
coachingOverlay.activatesAutomatically = true
arView.addSubview(coachingOverlay)

NSLayoutConstraint.activate([
    coachingOverlay.centerXAnchor.constraint(equalTo: arView.centerXAnchor),
    coachingOverlay.centerYAnchor.constraint(equalTo: arView.centerYAnchor),
    coachingOverlay.widthAnchor.constraint(equalTo: arView.widthAnchor),
    coachingOverlay.heightAnchor.constraint(equalTo: arView.heightAnchor)])

let fileURL = Bundle.main.url(forResource: "StBasilCath", withExtension: "reality")
let basilsScene = try! Entity.load(contentsOf: fileURL!)

let anchor = AnchorEntity(plane: .horizontal)
anchor.addChild(basilsScene)
anchor.scale = [1,1,1]

arView.contentScaleFactor = 1
arView.scene.addAnchor(anchor)
arView.session.run(config)

NotificationCenter.default.addObserver(forName: UIApplication.didReceiveMemoryWarningNotification, object: nil, queue: nil) {
    _ in arView.contentScaleFactor = max(arView.contentScaleFactor, 0.1)
}

do {
    player = try AVAudioPlayer(contentsOf: url)
    player?.play()
} catch {
    print("Please check if all the resources are in the correct place :)")
}

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = arView
PlaygroundPage.current.wantsFullScreenLiveView = true

