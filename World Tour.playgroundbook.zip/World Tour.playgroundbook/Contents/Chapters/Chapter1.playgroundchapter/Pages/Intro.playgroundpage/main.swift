/*:
 # World Tour - From Home
 WWDC 2020 Swift Student Challenge Submission by Aurther Nadeem
 
 ## Overview
 This Swift Playground will allow you to tour the world and see some major landmarks in an interactive augmented reality (AR) experience.
 
 Each AR experience can be experienced within 30 seconds, however, if you want you can go ahead and walk around each of the landmarks and tap on the hanging signs.
 
 My idea for this Playground sprouted from the lockdown we're currently in. With minimal air travel occuring at the moment people can't currently experience the world. So the second best thing is to bring the world into your home with AR, and with that my Swift Playground was born.
 
 ## Sources
 - [Earth Texture](https://www.solarsystemscope.com/textures) used for Earth's texture.
 
 - Important:
For the best User Experience turn off silent mode, turn up your volume 🔊, turn on Dark Mode 🌙 and hold your iPad Pro horizontally.
 This Playground had been tested on iPad Pro 10.5 inch and iPad Pro 11 inch (2nd Generation). It may crash or not perform as well on certain iPad models.
 
Go to the [next page](@next) when you're ready to move on.
 */

import PlaygroundSupport
import RealityKit
import UIKit
import ARKit

let arView = ARView(frame:.infinite, cameraMode: .ar, automaticallyConfigureSession: true)
let config = ARWorldTrackingConfiguration()
config.planeDetection = .horizontal
config.isLightEstimationEnabled = true

let coachingOverlay = ARCoachingOverlayView()
coachingOverlay.session = arView.session
coachingOverlay.translatesAutoresizingMaskIntoConstraints = false
coachingOverlay.activatesAutomatically = true
arView.addSubview(coachingOverlay)

NSLayoutConstraint.activate([
    coachingOverlay.centerXAnchor.constraint(equalTo: arView.centerXAnchor),
    coachingOverlay.centerYAnchor.constraint(equalTo: arView.centerYAnchor),
    coachingOverlay.widthAnchor.constraint(equalTo: arView.widthAnchor),
    coachingOverlay.heightAnchor.constraint(equalTo: arView.heightAnchor)])

let fileURL = Bundle.main.url(forResource: "worldTour", withExtension: "reality")
let introScene = try! Entity.load(contentsOf: fileURL!)

let anchor = AnchorEntity(plane: .horizontal)
anchor.addChild(introScene)
anchor.scale = [1,1,1]

arView.contentScaleFactor = 1
arView.scene.addAnchor(anchor)
arView.session.run(config)

NotificationCenter.default.addObserver(forName: UIApplication.didReceiveMemoryWarningNotification, object: nil, queue: nil) {
    _ in arView.contentScaleFactor = max(arView.contentScaleFactor, 0.1)
}

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = arView
PlaygroundPage.current.wantsFullScreenLiveView = true

