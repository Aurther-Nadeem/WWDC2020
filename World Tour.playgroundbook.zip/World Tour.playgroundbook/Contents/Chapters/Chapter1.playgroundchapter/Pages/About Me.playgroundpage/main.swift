/*:
 # About Me
 
 This Playground Page is about me designing, coding and fixing bugs in my Playgrounds. It's also about my experience of going to WWDC 2019. Overall making my Playground has been fun and I really enjoyed the process. Furthermore, I used frameworks I had never used before such as SwiftUI (because I enjoy using Storyboards). By using such frameworks its allowed me to appreciate the ease of use for some features in SwiftUI.
 
 I hope you enjoyed my Playground.
 
 - Important:
For the best User Experience turn off silent mode, turn up your volume 🔊, turn on Dark Mode 🌙 and hold your iPad Pro horizontally.
 
 */


import SwiftUI
import PlaygroundSupport
import UIKit
import AVFoundation

var player: AVAudioPlayer?

let path = Bundle.main.path(forResource: "AboutMe.m4a", ofType: nil)!
let url = URL(fileURLWithPath: path)


PlaygroundPage.current.wantsFullScreenLiveView = true


struct ContentView: View {
    
    @State var isShown = false
    @State var isOnTopLeft = false
    @State private var page = 0
    
    var body: some View {
        
        VStack() {
            
            HStack (alignment: .center) {
                Spacer().frame(width: 47 )
                Image(uiImage: UIImage(named: "mee.JPG")!).resizable()
                    .frame(width: 125.0, height: 125.0)
                    .clipShape(Circle())
                    .shadow(radius: 10)
                    .overlay(Circle().stroke(Color.gray, lineWidth: 8.0))
                    .padding()
                
                VStack(alignment: .leading) {
                    Text("About Me")
                        .font(.system(size: 22.5, weight: .bold ))
                    Text("Aurther Nadeem - 16")
                        .font(.system(size: 17.5, weight: .semibold ))
                }
                
                
                if isOnTopLeft {
                    Spacer(minLength: 0.0)
                }
                
                
            }
                
            .opacity(self.isShown ? 1.0 : 0.0)
                .animation(.easeInOut(duration: 0.9))
                
                .onAppear {
                    self.isShown = true
                    DispatchQueue.main.asyncAfter(deadline: .now()  + 1.3) {
                        self.isOnTopLeft = true
                    }
            }
            
            if isOnTopLeft {
                Spacer().frame(height: 0)
            }
            
            HStack (alignment: .center){
                VStack (alignment: .leading) {
                    Picker("Page", selection: $page) {
                        Text("Fact 1").tag(0)
                        Text("Fact 2").tag(1)
                        Text("Fact 3").tag(2)
                        Text("Fact 4").tag(3)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .frame(width: 320, height: 120, alignment: .center)
                    PageView([
                        Text("I've currently got 2 apps on the App Store."),
                        Text("I made my first app called 'Quickk Maths' when I was 13."),
                        Text("My favourite technologies are AR and ML."),
                        Text("I have made a total of 124 iterations to finish this Playground.")
                    ], currentPage: $page)
                        .frame(width: 320, height: 120, alignment: .center)
                        .overlay(RoundedRectangle(cornerRadius: 10) .stroke(Color.gray, lineWidth: 2))
                }
                    
                    VStack{
                        Text("Hey there, I'm Aurther from the UK, life is kinda upside down at the moment with the Coronavirus. This is my fourth year applying for an Apple Coding Challenge (counting WWDC), and I have learnt a lot from these applications. For this year I pushed myself out of my comfort zone by using SwiftUI and RealityKit, two frameworks I've never used.").frame(width: 630, height: 120)
                            .multilineTextAlignment(.center)
                            
                            .overlay(RoundedRectangle(cornerRadius: 10) .stroke(Color.gray, lineWidth: 5))
                            .opacity(self.isShown ? 1.0 : 0.0)
                            .animation(.easeInOut(duration: 1.2))
                            .padding()
                        
                        Text("WWDC19 was a blast, it is easily one of the best weeks of my life. I gained an unmeasurable amount of knowledge in that one week. All the people there were great and it allowed me to gain a lot of new friends, over there I felt like I was part of a community. All of the labs were useful, especially the UI one and the Accessibility one. (I never knew iOS had so many accessibility options). I loved every minute of being at WWDC and it's a shame its digital this year.").frame(width: 630, height: 150)
                            .multilineTextAlignment(.center)
                            
                            .overlay(RoundedRectangle(cornerRadius: 10) .stroke(Color.gray, lineWidth: 5))
                            .opacity(self.isShown ? 1.0 : 0.0)
                            .animation(.easeInOut(duration: 1.2))
                            .padding()
                    }
                .opacity(self.isShown ? 1.0 : 0.0)
                    .animation(.easeInOut(duration: 0.9))
            }
            
            ScrollView(.horizontal, showsIndicators: true) {
                HStack(spacing: 16) {
                    Image(uiImage: UIImage(named: "badge.jpg")!).resizable()
                        .frame(width: 130, height: 180)
                        .overlay(RoundedRectangle(cornerRadius: 10) .stroke(Color.gray, lineWidth: 5))
                        .opacity(self.isShown ? 1.0 : 0.0)
                    
                    Image(uiImage: UIImage(named: "Keynote.jpg")!).resizable()
                        .frame(width: 130, height: 180)
                        .overlay(RoundedRectangle(cornerRadius: 10) .stroke(Color.gray, lineWidth: 5))
                        .opacity(self.isShown ? 1.0 : 0.0)
                    
                    Image(uiImage: UIImage(named: "iJus.jpg")!).resizable()
                        .frame(width: 130, height: 180)
                        .overlay(RoundedRectangle(cornerRadius: 10) .stroke(Color.gray, lineWidth: 5))
                        .opacity(self.isShown ? 1.0 : 0.0)
                    
                    Image(uiImage: UIImage(named: "mPro.jpg")!).resizable()
                        .frame(width: 130, height: 180)
                        .overlay(RoundedRectangle(cornerRadius: 10) .stroke(Color.gray, lineWidth: 5))
                        .opacity(self.isShown ? 1.0 : 0.0)
                    
                    Image(uiImage: UIImage(named: "waiting.jpg")!).resizable()
                        .frame(width: 130, height: 180)
                        .overlay(RoundedRectangle(cornerRadius: 10) .stroke(Color.gray, lineWidth: 5))
                        .opacity(self.isShown ? 1.0 : 0.0)
                    
                    Image(uiImage: UIImage(named: "showing.jpg")!).resizable()
                        .frame(width: 130, height: 180)
                        .overlay(RoundedRectangle(cornerRadius: 10) .stroke(Color.gray, lineWidth: 5))
                        .opacity(self.isShown ? 1.0 : 0.0)
                    
                    Image(uiImage: UIImage(named: "dubdub.jpg")!).resizable()
                        .frame(width: 270, height: 180)
                        .overlay(RoundedRectangle(cornerRadius: 10) .stroke(Color.gray, lineWidth: 5))
                        .opacity(self.isShown ? 1.0 : 0.0)
                    
                    Image(uiImage: UIImage(named: "group.jpg")!).resizable()
                    .frame(width: 300, height: 180)
                    .overlay(RoundedRectangle(cornerRadius: 10) .stroke(Color.gray, lineWidth: 5))
                    .opacity(self.isShown ? 1.0 : 0.0)
                    
             

                }
                .animation(.easeInOut(duration: 3))
            }
        
            
            
            
            
        }
    }
    
}



struct PageViewController: UIViewControllerRepresentable {
    var controllers: [UIViewController]
    @Binding var currentPage: Int
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    func makeUIViewController(context: Context) -> UIPageViewController {
        let pageViewController = UIPageViewController(
            transitionStyle: .scroll,
            navigationOrientation: .horizontal)
        pageViewController.dataSource = context.coordinator
        pageViewController.delegate = context.coordinator
        
        return pageViewController
    }
    
    func updateUIViewController(_ pageViewController: UIPageViewController, context: Context) {
        pageViewController.setViewControllers(
            [controllers[currentPage]], direction: .forward, animated: true)
    }
    
    class Coordinator: NSObject, UIPageViewControllerDataSource, UIPageViewControllerDelegate {
        var parent: PageViewController
        
        init(_ pageViewController: PageViewController) {
            self.parent = pageViewController
        }
        
        func pageViewController(
            _ pageViewController: UIPageViewController,
            viewControllerBefore viewController: UIViewController) -> UIViewController?
        {
            guard let index = parent.controllers.firstIndex(of: viewController) else {
                return nil
            }
            if index == 0 {
                return nil
            }
            return parent.controllers[index - 1]
        }
        
        func pageViewController(
            _ pageViewController: UIPageViewController,
            viewControllerAfter viewController: UIViewController) -> UIViewController?
        {
            guard let index = parent.controllers.firstIndex(of: viewController) else {
                return nil
            }
            if index + 1 == parent.controllers.count {
                return nil
            }
            return parent.controllers[index + 1]
        }
        
        func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
            if completed,
                let visibleViewController = pageViewController.viewControllers?.first,
                let index = parent.controllers.firstIndex(of: visibleViewController)
            {
                parent.currentPage = index
            }
        }
    }
}

#if DEBUG
struct PageViewController_Previews: PreviewProvider {
    @State static var currentPage = 0
    
    static var previews: some View {
        PageViewController(controllers: [], currentPage: $currentPage)
    }
}
#endif

struct PageView<Page: View>: View {
    var viewControllers: [UIHostingController<Page>]
    @Binding var currentPage: Int
    
    init(_ views: [Page], currentPage: Binding<Int>) {
        self._currentPage = currentPage
        self.viewControllers = views.map { UIHostingController(rootView: $0) }
    }
    
    var body: some View {
        PageViewController(controllers: viewControllers, currentPage: $currentPage)
    }
}

#if DEBUG
struct PageView_Previews: PreviewProvider {
    @State static var page = 0
    static var previews: some View {
        PageView([Text("Hello")], currentPage: $page)
    }
}
#endif

do {
    player = try AVAudioPlayer(contentsOf: url)
    player?.play()
} catch {
    print("Please check if all the resources are in the correct place :)")
}

var controller = UIHostingController(rootView: ContentView())
PlaygroundPage.current.liveView = controller
