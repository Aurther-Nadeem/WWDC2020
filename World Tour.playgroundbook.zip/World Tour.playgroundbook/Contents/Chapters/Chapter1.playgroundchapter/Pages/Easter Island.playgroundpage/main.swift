/*:
# Moai Statues, Easter Island, Chile
The big stone heads on Easter Island

Welcome to Easter Island. The island is best known for the Moai Statues scattered across it. There are also 3 major volcanoes on Easter Island.

Here's some fun facts about Easter Island:
- There are 887 known Moai Statues on the island.
- Easter Island is also known as Rapa Nui.
- The first recorded European visitor was on Easter day 1722, hence the name.
- The total population of Easter Island is 5,800.
- Nearly all the Moai were carved from solidified volcanic ash.

Make sure to get up and walk around the Moai Statue.

- Important:
For the best User Experience turn off silent mode, turn up your volume 🔊, turn on Dark Mode 🌙 and hold your iPad Pro horizontally.

Go to the [next page](@next) when you're ready to move on.
*/

import PlaygroundSupport
import RealityKit
import UIKit
import ARKit
import AVFoundation

var player: AVAudioPlayer?

let path = Bundle.main.path(forResource: "EasterIsland.m4a", ofType: nil)!
let url = URL(fileURLWithPath: path)

let arView = ARView(frame:.infinite, cameraMode: .ar, automaticallyConfigureSession: true)
let config = ARWorldTrackingConfiguration()
config.planeDetection = .horizontal
config.isLightEstimationEnabled = true

let coachingOverlay = ARCoachingOverlayView()
coachingOverlay.session = arView.session
coachingOverlay.translatesAutoresizingMaskIntoConstraints = false
coachingOverlay.activatesAutomatically = true
arView.addSubview(coachingOverlay)

NSLayoutConstraint.activate([
    coachingOverlay.centerXAnchor.constraint(equalTo: arView.centerXAnchor),
    coachingOverlay.centerYAnchor.constraint(equalTo: arView.centerYAnchor),
    coachingOverlay.widthAnchor.constraint(equalTo: arView.widthAnchor),
    coachingOverlay.heightAnchor.constraint(equalTo: arView.heightAnchor)])

let fileURL = Bundle.main.url(forResource: "EasterIsland", withExtension: "reality")
let easterIslandScene = try! Entity.load(contentsOf: fileURL!)

let anchor = AnchorEntity(plane: .horizontal)
anchor.addChild(easterIslandScene)
anchor.scale = [1,1,1]

arView.contentScaleFactor = 1
arView.scene.addAnchor(anchor)
arView.session.run(config)

NotificationCenter.default.addObserver(forName: UIApplication.didReceiveMemoryWarningNotification, object: nil, queue: nil) {
    _ in arView.contentScaleFactor = max(arView.contentScaleFactor, 0.1)
}

do {
    player = try AVAudioPlayer(contentsOf: url)
    player?.play()
} catch {
    print("Please check if all the resources are in the correct place :)")
}

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = arView
PlaygroundPage.current.wantsFullScreenLiveView = true

