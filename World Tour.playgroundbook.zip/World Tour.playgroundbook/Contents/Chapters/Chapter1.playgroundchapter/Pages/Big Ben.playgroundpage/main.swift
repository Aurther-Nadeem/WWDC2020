/*:
# Big Ben, London, England
The Tower Clock in London

Welcome to London. We are known for rain and bad weather. Did you know over half of the London Underground runs above ground? (I didn't even know that and I live in the UK).

Here's some fun facts about London:
- Each year London buses travel about 12,128 times the circumference of the Earth (roughly 302 million miles).
- There are over 300 lanuages spoken in London, the most popular are English, Bengali, Gujarati and Mandarin.
- The Shard is the tallest building in the EU.
- The total population of London is 8.7 million.
- London has hosted the Olympics three times.

Make sure to get up and walk around the Big Ben.

- Important:
For the best User Experience turn off silent mode, turn up your volume 🔊, turn on Dark Mode 🌙 and hold your iPad Pro horizontally.

Go to the [next page](@next) when you're ready to move on.
*/

import PlaygroundSupport
import RealityKit
import UIKit
import ARKit
import AVFoundation

var player: AVAudioPlayer?

let path = Bundle.main.path(forResource: "London.m4a", ofType: nil)!
let url = URL(fileURLWithPath: path)


let arView = ARView(frame:.infinite, cameraMode: .ar, automaticallyConfigureSession: true)
let config = ARWorldTrackingConfiguration()
config.planeDetection = .horizontal
config.isLightEstimationEnabled = true

let coachingOverlay = ARCoachingOverlayView()
coachingOverlay.session = arView.session
coachingOverlay.translatesAutoresizingMaskIntoConstraints = false
coachingOverlay.activatesAutomatically = true
arView.addSubview(coachingOverlay)

NSLayoutConstraint.activate([
    coachingOverlay.centerXAnchor.constraint(equalTo: arView.centerXAnchor),
    coachingOverlay.centerYAnchor.constraint(equalTo: arView.centerYAnchor),
    coachingOverlay.widthAnchor.constraint(equalTo: arView.widthAnchor),
    coachingOverlay.heightAnchor.constraint(equalTo: arView.heightAnchor)])

let fileURL = Bundle.main.url(forResource: "BigBen", withExtension: "reality")
let bigBenScene = try! Entity.load(contentsOf: fileURL!)

let anchor = AnchorEntity(plane: .horizontal)
anchor.addChild(bigBenScene)
anchor.scale = [1,1,1]

arView.contentScaleFactor = 1
arView.scene.addAnchor(anchor)
arView.session.run(config)

NotificationCenter.default.addObserver(forName: UIApplication.didReceiveMemoryWarningNotification, object: nil, queue: nil) {
    _ in arView.contentScaleFactor = max(arView.contentScaleFactor, 0.1)
}

do {
    player = try AVAudioPlayer(contentsOf: url)
    player?.play()
} catch {
    print("Please check if all the resources are in the correct place :)")
}

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = arView
PlaygroundPage.current.wantsFullScreenLiveView = true



