/*:
# Eiffel Tower, Paris, France
Most well known landmark in Europe

Welcome to Paris. They call it the city of love and the city of light (La Ville-Lumière). Having been there I didn't feel much love but I saw a lot of lights.

Here's some fun facts about Paris:
- Paris was originally a Roman City called Lutetia.
- There is only one STOP sign in the whole city.
- There are more dogs than children in Paris.
- The total population of Paris is 2.2 million.
- 25,000 people a day head up the Eiffel Tower.

Make sure to get up and walk around the Eiffel Tower and tap on the hanging signs.

- Important:
For the best User Experience turn off silent mode, turn up your volume 🔊, turn on Dark Mode 🌙 and hold your iPad Pro horizontally.

Go to the [next page](@next) when you're ready to move on.
*/

import PlaygroundSupport
import RealityKit
import UIKit
import ARKit
import AVFoundation

var player: AVAudioPlayer?

let path = Bundle.main.path(forResource: "Paris.m4a", ofType: nil)!
let url = URL(fileURLWithPath: path)


let arView = ARView(frame:.infinite, cameraMode: .ar, automaticallyConfigureSession: true)
let config = ARWorldTrackingConfiguration()
config.planeDetection = .horizontal
config.isLightEstimationEnabled = true

let coachingOverlay = ARCoachingOverlayView()
coachingOverlay.session = arView.session
coachingOverlay.translatesAutoresizingMaskIntoConstraints = false
coachingOverlay.activatesAutomatically = true
arView.addSubview(coachingOverlay)

NSLayoutConstraint.activate([
    coachingOverlay.centerXAnchor.constraint(equalTo: arView.centerXAnchor),
    coachingOverlay.centerYAnchor.constraint(equalTo: arView.centerYAnchor),
    coachingOverlay.widthAnchor.constraint(equalTo: arView.widthAnchor),
    coachingOverlay.heightAnchor.constraint(equalTo: arView.heightAnchor)])

let fileURL = Bundle.main.url(forResource: "EiffelTower", withExtension: "reality")
let eiffelTowerScene = try! Entity.load(contentsOf: fileURL!)

let anchor = AnchorEntity(plane: .horizontal)
anchor.addChild(eiffelTowerScene)
anchor.scale = [1,1,1]

arView.contentScaleFactor = 1
arView.scene.addAnchor(anchor)
arView.session.run(config)

NotificationCenter.default.addObserver(forName: UIApplication.didReceiveMemoryWarningNotification, object: nil, queue: nil) {
    _ in arView.contentScaleFactor = max(arView.contentScaleFactor, 0.1)
}

do {
    player = try AVAudioPlayer(contentsOf: url)
    player?.play()
} catch {
    print("Please check if all the resources are in the correct place :)")
}

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = arView
PlaygroundPage.current.wantsFullScreenLiveView = true


